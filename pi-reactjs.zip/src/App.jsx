import "../src/App.css";
import AppRoutes from "./routes.jsx";

function App() {
  return <>
      <AppRoutes />
  </> ;
}

export default App;
